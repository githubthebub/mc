
public interface InjectedInterface {
	default void newMethodThatDidNotExist() {
	}
}
