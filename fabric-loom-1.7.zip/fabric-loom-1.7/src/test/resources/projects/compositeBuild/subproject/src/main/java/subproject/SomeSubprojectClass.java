package external;

public class SomeSubprojectClass {
}