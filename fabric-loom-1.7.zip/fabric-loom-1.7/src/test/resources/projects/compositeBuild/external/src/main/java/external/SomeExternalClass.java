package external;

public class SomeExternalClass {
}